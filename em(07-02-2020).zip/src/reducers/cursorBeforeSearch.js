export default (state, { value }) => ({
  cursorBeforeSearch: value
})
