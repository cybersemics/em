/** Encapsulates mutating sort */
export const sort = (arr, ...args) => [...arr].sort(...args) // eslint-disable-line fp/no-mutating-methods
