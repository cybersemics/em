export const ADD_THOUGHT = 'add_thought';
export const RECENTLY_EDITED_THOUGHTS = 'recently_edited_thoughts';