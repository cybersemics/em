import { head } from './head.js'

export const headValue = thoughtsRanked => head(thoughtsRanked).value
