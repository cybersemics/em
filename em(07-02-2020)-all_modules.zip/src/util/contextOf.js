/** Gets the context of a context */
export const contextOf = context => context.slice(0, context.length - 1)
