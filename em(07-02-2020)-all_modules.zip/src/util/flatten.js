export const flatten = list => Array.prototype.concat.apply([], list)
