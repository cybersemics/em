export default (state, { value }) => ({
  status: value
})
