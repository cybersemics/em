export default state => ({
  showQueue: !state.showQueue
})
