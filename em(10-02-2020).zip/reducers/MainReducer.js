import ThoughtReducer from './ThoughtReducer'


export default (state = initialState(), action) => {
  return {...state, ThoughtReducer : ThoughtReducer}
  
}
