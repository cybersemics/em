/** gets the signifying label of the given context.
  Declare using traditional function syntax so it is hoisted
*/
export const head = thoughts => thoughts[thoughts.length - 1]
