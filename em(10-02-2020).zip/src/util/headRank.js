import { head } from './head.js'

export const headRank = thoughtsRanked => head(thoughtsRanked).rank
