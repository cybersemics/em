export const timestamp = () => (new Date()).toISOString()
