import { RedoIcon } from '../components/redoIcon'

export default {
  id: 'redo',
  name: 'Redo',
  description: 'Redo',
  svg: RedoIcon,
  exec: () => { }
}
