export default (state, { value }) => ({
  search: value
})
