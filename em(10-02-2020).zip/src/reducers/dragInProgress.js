export default (state, { value }) => ({
  dragInProgress: value
})
