export default (state, { value }) => ({
  searchLimit: value
})
