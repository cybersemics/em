export const isDivider = s =>
  s && (s.startsWith('---') || s.startsWith('—'))
