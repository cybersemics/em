import {
  NUMBERS,
} from '../constants.js'

// util
export const spellNumber = n => NUMBERS[n - 1] || n
