import { makeCompareByProp } from './makeCompareByProp.js'

export const compareByRank = makeCompareByProp('rank')
