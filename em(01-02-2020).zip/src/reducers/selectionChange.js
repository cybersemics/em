export default (state, { focusOffset }) => ({
  focusOffset
})
