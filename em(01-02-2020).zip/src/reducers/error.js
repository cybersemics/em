export default (state, { value }) => ({
  error: value
})
